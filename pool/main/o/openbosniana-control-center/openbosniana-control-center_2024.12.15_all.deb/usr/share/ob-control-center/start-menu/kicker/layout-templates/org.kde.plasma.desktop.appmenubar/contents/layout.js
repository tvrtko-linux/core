var panel = new Panel
panel.location = "top";
panel.height = Math.round(gridUnit * 1.5);

panel.addWidget("org.kde.plasma.appmenu");
