
python bigbashview.py -s 870x520 -c -i ob-cc index.sh.htm 2> /dev/null;
