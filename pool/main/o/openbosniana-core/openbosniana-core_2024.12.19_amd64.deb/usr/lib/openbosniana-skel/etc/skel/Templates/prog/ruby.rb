#!/usr/bin/ruby

puts "OpenBosniana GNU/Linux"
