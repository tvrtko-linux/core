#!/bin/bash
# SPDX-License-Identifier: LGPL-2.1-or-later

echo "Honor first shutdown test script"
sleep infinity;
