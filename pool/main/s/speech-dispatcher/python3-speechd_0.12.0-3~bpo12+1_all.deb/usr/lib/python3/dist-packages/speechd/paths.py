SPD_SPAWN_CMD = "/usr/bin/speech-dispatcher"
