#define UTS_RELEASE "6.12.12+bpo-amd64"
