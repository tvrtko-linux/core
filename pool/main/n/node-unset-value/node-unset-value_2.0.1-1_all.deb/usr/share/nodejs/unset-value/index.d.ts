declare function unset(obj: Record<PropertyKey, unknown>, prop: string | string[]): boolean;

export = unset;
