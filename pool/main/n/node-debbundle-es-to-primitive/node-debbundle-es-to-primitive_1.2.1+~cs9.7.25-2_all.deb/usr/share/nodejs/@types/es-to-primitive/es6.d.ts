import ToPrimitive = require('./es2015');
/** @deprecated */
export = ToPrimitive;
