var parent = require('../../stable/typed-array/fill');

module.exports = parent;
