module.exports = require('../../full/array/to-reversed');
