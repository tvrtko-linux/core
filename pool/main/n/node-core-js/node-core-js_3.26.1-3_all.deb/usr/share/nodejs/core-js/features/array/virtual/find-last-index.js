module.exports = require('../../../full/array/virtual/find-last-index');
