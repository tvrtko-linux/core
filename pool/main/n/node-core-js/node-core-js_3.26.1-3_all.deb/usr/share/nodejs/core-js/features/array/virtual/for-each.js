module.exports = require('../../../full/array/virtual/for-each');
