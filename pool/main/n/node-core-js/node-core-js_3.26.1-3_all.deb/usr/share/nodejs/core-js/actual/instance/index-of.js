var parent = require('../../stable/instance/index-of');

module.exports = parent;
