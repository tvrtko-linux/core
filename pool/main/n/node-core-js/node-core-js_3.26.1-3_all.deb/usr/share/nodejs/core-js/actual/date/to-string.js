var parent = require('../../stable/date/to-string');

module.exports = parent;
