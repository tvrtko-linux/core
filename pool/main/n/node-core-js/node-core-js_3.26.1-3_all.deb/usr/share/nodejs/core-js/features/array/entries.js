module.exports = require('../../full/array/entries');
