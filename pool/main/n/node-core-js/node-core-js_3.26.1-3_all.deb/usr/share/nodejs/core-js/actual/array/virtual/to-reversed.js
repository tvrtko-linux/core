require('../../../modules/esnext.array.to-reversed');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').toReversed;
