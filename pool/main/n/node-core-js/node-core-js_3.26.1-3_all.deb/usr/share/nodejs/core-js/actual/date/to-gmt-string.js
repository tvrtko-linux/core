var parent = require('../../stable/date/to-gmt-string');

module.exports = parent;
