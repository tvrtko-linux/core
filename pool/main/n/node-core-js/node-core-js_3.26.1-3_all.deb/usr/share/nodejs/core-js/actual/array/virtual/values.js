var parent = require('../../../stable/array/virtual/values');

module.exports = parent;
