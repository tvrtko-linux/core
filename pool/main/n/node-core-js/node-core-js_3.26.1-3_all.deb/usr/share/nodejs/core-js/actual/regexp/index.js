var parent = require('../../stable/regexp');

module.exports = parent;
