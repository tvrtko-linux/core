var parent = require('../../../stable/string/virtual/includes');

module.exports = parent;
