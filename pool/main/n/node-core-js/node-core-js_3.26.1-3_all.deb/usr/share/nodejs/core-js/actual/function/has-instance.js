var parent = require('../../stable/function/has-instance');

module.exports = parent;
