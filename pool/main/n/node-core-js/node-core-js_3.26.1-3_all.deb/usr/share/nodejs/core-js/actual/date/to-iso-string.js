var parent = require('../../stable/date/to-iso-string');

module.exports = parent;
