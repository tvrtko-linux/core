var parent = require('../../stable/array-buffer');

module.exports = parent;
