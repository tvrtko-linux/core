var parent = require('../../../stable/string/virtual/starts-with');

module.exports = parent;
