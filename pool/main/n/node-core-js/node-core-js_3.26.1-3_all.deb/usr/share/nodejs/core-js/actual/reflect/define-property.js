var parent = require('../../stable/reflect/define-property');

module.exports = parent;
