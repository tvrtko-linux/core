var parent = require('../../stable/typed-array/index-of');

module.exports = parent;
