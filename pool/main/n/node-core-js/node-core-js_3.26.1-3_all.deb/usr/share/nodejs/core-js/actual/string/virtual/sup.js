var parent = require('../../../stable/string/virtual/sup');

module.exports = parent;
