var parent = require('../../stable/math/hypot');

module.exports = parent;
