module.exports = require('../../full/array/push');
