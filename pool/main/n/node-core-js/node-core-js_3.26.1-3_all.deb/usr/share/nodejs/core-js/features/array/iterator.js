module.exports = require('../../full/array/iterator');
