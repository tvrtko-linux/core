var parent = require('../../stable/symbol/has-instance');

module.exports = parent;
