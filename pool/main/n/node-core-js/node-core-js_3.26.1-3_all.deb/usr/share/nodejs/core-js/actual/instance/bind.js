var parent = require('../../stable/instance/bind');

module.exports = parent;
