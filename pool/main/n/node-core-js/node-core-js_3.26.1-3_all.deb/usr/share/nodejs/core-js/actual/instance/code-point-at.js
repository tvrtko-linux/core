var parent = require('../../stable/instance/code-point-at');

module.exports = parent;
