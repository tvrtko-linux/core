var parent = require('../../stable/error/constructor');

module.exports = parent;
