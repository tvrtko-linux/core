var parent = require('../../stable/regexp/search');

module.exports = parent;
