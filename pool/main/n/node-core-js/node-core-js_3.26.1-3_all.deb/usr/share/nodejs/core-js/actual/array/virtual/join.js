var parent = require('../../../stable/array/virtual/join');

module.exports = parent;
