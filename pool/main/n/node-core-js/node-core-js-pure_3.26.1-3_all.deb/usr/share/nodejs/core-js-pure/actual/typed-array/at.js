var parent = require('../../stable/typed-array/at');

module.exports = parent;
