var parent = require('../../../stable/array/virtual/copy-within');

module.exports = parent;
