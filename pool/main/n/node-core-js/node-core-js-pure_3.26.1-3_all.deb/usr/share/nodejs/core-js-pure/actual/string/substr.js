var parent = require('../../stable/string/substr');

module.exports = parent;
