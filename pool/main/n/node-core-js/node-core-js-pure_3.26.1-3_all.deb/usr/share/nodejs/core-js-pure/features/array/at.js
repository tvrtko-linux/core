module.exports = require('../../full/array/at');
