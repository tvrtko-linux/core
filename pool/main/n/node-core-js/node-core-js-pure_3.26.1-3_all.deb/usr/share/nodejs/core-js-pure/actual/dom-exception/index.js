var parent = require('../../stable/dom-exception');

module.exports = parent;
