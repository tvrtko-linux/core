require('../../modules/es.array.sort');
require('../../modules/esnext.array.to-sorted');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'toSorted');
