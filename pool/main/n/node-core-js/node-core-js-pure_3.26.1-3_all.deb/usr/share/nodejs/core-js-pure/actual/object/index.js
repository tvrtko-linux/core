var parent = require('../../stable/object');

module.exports = parent;
