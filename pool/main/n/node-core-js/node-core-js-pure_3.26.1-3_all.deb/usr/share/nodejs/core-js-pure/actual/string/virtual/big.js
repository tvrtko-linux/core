var parent = require('../../../stable/string/virtual/big');

module.exports = parent;
