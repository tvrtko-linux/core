module.exports = require('../../full/array/last-item');
