require('../../../modules/esnext.array.to-spliced');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').toSpliced;
