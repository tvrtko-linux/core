var parent = require('../../stable/typed-array/uint8-clamped-array');
require('../../actual/typed-array/methods');

module.exports = parent;
