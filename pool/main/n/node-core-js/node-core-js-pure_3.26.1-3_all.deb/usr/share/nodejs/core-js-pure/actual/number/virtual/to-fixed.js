var parent = require('../../../stable/number/virtual/to-fixed');

module.exports = parent;
