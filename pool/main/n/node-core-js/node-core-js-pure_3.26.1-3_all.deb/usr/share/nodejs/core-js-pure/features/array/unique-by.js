module.exports = require('../../full/array/unique-by');
