module.exports = require('../../full/array/map');
