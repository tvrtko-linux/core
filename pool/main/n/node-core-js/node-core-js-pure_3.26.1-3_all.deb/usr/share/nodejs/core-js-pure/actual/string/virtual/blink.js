var parent = require('../../../stable/string/virtual/blink');

module.exports = parent;
