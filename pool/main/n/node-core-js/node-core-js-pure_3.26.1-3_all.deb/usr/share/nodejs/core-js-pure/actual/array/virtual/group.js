require('../../../modules/esnext.array.group');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').group;
