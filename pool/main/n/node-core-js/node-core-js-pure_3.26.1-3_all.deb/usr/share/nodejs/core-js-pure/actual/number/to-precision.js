var parent = require('../../stable/number/to-precision');

module.exports = parent;
