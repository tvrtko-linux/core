var parent = require('../../stable/instance/concat');

module.exports = parent;
