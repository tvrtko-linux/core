module.exports = require('../../../full/array/virtual/flat-map');
