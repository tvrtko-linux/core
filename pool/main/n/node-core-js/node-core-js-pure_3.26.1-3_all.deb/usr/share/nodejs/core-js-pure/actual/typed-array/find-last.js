require('../../modules/esnext.typed-array.find-last');
var parent = require('../../stable/typed-array/find-last');

module.exports = parent;
