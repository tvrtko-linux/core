var parent = require('../../stable/math/fround');

module.exports = parent;
