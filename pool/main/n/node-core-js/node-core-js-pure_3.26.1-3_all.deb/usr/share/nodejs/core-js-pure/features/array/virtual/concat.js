module.exports = require('../../../full/array/virtual/concat');
