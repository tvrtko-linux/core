var parent = require('../../stable/map');

module.exports = parent;
