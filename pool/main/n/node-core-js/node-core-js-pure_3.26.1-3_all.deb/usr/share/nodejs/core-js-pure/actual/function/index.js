var parent = require('../../stable/function');

module.exports = parent;
