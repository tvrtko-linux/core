var parent = require('../../stable/array/is-array');

module.exports = parent;
