require('../../modules/es.typed-array.sort');
require('../../modules/esnext.typed-array.to-sorted');
