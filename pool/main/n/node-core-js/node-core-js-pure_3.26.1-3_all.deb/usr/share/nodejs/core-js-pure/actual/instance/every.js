var parent = require('../../stable/instance/every');

module.exports = parent;
