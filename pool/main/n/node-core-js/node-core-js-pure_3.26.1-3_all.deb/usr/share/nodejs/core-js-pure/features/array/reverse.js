module.exports = require('../../full/array/reverse');
