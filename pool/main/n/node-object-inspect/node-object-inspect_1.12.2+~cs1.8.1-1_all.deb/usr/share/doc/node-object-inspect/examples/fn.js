'use strict';

var inspect = require('node-object-inspect');
var obj = [1, 2, function f(n) { return n + 5; }, 4];
console.log(inspect(obj));
