ESQuery is a library for querying the AST output by Esprima for patterns
of syntax using a CSS style selector system. Check out the demo:

demo

The following selectors are supported:

-   AST node type: ForStatement
-   wildcard: *
-   attribute existence: [attr]
-   attribute value: [attr="foo"] or [attr=123]
-   attribute regex: [attr=/foo.*/] or (with flags) [attr=/foo.*/is]
-   attribute conditions: [attr!="foo"], [attr>2], [attr<3], [attr>=2],
    or [attr<=3]
-   nested attribute: [attr.level2="foo"]
-   field: FunctionDeclaration > Identifier.id
-   First or last child: :first-child or :last-child
-   nth-child (no ax+b support): :nth-child(2)
-   nth-last-child (no ax+b support): :nth-last-child(1)
-   descendant: ancestor descendant
-   child: parent > child
-   following sibling: node ~ sibling
-   adjacent sibling: node + adjacent
-   negation: :not(ForStatement)
-   has: :has(ForStatement)
-   matches-any: :matches([attr] > :first-child, :last-child)
-   subject indicator: !IfStatement > [name="foo"]
-   class of AST node: :statement, :expression, :declaration, :function,
    or :pattern
