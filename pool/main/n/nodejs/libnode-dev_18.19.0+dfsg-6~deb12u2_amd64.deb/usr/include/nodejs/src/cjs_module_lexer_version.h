// This is an auto generated file, please do not edit.
// Refer to tools/dep_updaters/update-cjs-module-lexer.sh
#ifndef SRC_CJS_MODULE_LEXER_VERSION_H_
#define SRC_CJS_MODULE_LEXER_VERSION_H_
#define CJS_MODULE_LEXER_VERSION "1.2.2"
#endif  // SRC_CJS_MODULE_LEXER_VERSION_H_
