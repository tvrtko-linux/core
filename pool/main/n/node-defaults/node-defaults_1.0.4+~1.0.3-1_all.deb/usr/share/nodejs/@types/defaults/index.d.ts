// Type definitions for defaults 1.0.3
// Project: https://github.com/tmpvar/defaults/
// Definitions by: Ibtihel CHNAB <https://github.com/IbtihelCHNAB>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped

declare module "defaults" {
  function defaults(options: any, defaultOptions: any): any;

  export = defaults;
}
