This is a stub types definition for @types/fast-json-stable-stringify (https://github.com/epoberezkin/fast-json-stable-stringify).

fast-json-stable-stringify provides its own type definitions, so you don't need @types/fast-json-stable-stringify installed!