# @babel/plugin-proposal-function-sent

> Compile the function.sent meta property to valid ES2015 code

See our website [@babel/plugin-proposal-function-sent](https://babeljs.io/docs/en/babel-plugin-proposal-function-sent) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-function-sent
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-function-sent --dev
```
