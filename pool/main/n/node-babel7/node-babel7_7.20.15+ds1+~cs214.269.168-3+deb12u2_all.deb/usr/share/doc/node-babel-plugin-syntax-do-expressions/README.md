# @babel/plugin-syntax-do-expressions

> Allow parsing of do expressions

See our website [@babel/plugin-syntax-do-expressions](https://babeljs.io/docs/en/babel-plugin-syntax-do-expressions) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-do-expressions
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-do-expressions --dev
```
