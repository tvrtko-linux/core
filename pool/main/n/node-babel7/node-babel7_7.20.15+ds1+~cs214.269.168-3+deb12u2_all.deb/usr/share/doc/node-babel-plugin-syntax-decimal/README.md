# @babel/plugin-syntax-decimal

> Allow parsing of decimal

See our website [@babel/plugin-syntax-decimal](https://babeljs.io/docs/en/babel-plugin-syntax-decimal) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-decimal
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-decimal --dev
```
