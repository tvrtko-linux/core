# @babel/plugin-syntax-module-blocks

> Allow parsing of JS Module Blocks

See our website [@babel/plugin-syntax-module-blocks](https://babeljs.io/docs/en/babel-plugin-syntax-module-blocks) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-module-blocks
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-module-blocks --dev
```
