# @babel/plugin-syntax-explicit-resource-management

> Allow parsing of the using declarations

See our website [@babel/plugin-syntax-explicit-resource-management](https://babeljs.io/docs/en/babel-plugin-syntax-explicit-resource-management) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-explicit-resource-management
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-explicit-resource-management --dev
```
