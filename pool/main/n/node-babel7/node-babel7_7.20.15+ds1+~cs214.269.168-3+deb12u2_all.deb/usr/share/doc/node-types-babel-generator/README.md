# Installation
> `npm install --save @types/babel__generator`

# Summary
This package contains type definitions for @babel/generator (https://github.com/babel/babel/tree/master/packages/babel-generator).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__generator.

### Additional Details
 * Last updated: Thu, 23 Dec 2021 23:34:17 GMT
 * Dependencies: [@types/babel__types](https://npmjs.com/package/@types/babel__types)
 * Global values: none

# Credits
These definitions were written by [Troy Gerwien](https://github.com/yortus), [Melvin Groenhoff](https://github.com/mgroenhoff), [Cameron Yan](https://github.com/khell), and [Lyanbin](https://github.com/Lyanbin).
