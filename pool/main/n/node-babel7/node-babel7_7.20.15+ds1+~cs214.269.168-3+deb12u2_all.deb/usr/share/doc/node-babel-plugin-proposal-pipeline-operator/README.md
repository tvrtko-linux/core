# @babel/plugin-proposal-pipeline-operator

> Transform pipeline operator into call expressions

See our website [@babel/plugin-proposal-pipeline-operator](https://babeljs.io/docs/en/babel-plugin-proposal-pipeline-operator) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-pipeline-operator
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-pipeline-operator --dev
```
