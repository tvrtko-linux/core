# @babel/plugin-syntax-function-bind

> Allow parsing of function bind

See our website [@babel/plugin-syntax-function-bind](https://babeljs.io/docs/en/babel-plugin-syntax-function-bind) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-function-bind
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-function-bind --dev
```
