/**
Gracefully restore the CLI cursor on exit.

@example
```
import restoreCursor from 'restore-cursor';

restoreCursor();
```
*/
export default function restoreCursor(): void;
