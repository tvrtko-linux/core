declare module 'emoji-regex/text' {
  function emojiRegex(): RegExp;

  export = emojiRegex;
}
