ESLint Scope

ESLint Scope is the ECMAScript scope analyzer used in ESLint. It is a fork of escope.

Install

npm i eslint-scope --save

📖 Usage

To use in an ESM file:

import * as eslintScope from 'eslint-scope';

To use in a CommonJS file:

const eslintScope = require('eslint-scope');

Example:

import * as eslintScope from 'eslint-scope';
import * as espree from 'espree';
import estraverse from 'estraverse';

const ast = espree.parse(code, { range: true });
const scopeManager = eslintScope.analyze(ast);

const currentScope = scopeManager.acquire(ast);   // global scope

estraverse.traverse(ast, {
    enter (node, parent) {
        // do stuff

        if (/Function/.test(node.type)) {
            currentScope = scopeManager.acquire(node);  // get current function scope
        }
    },
    leave(node, parent) {
        if (/Function/.test(node.type)) {
            currentScope = currentScope.upper;  // set to parent scope
        }

        // do stuff
    }
});

Contributing

Issues and pull requests will be triaged and responded to as quickly as possible. We operate under the ESLint Contributor Guidelines, so please be sure to read them before contributing. If you're not sure where to dig in, check out the issues.

Build Commands

  - npm test - run all linting and tests
  - npm run lint - run all linting

License

ESLint Scope is licensed under a permissive BSD 2-clause license.
