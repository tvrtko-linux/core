# Installation
> `npm install --save @types/assert`

# Summary
This package contains type definitions for commonjs-assert (https://github.com/browserify/commonjs-assert).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/assert.

### Additional Details
 * Last updated: Thu, 26 Aug 2021 01:01:27 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Nico Gallinal](https://github.com/nicoabie), [Linus Unnebäck](https://github.com/LinusU), and [ExE Boss](https://github.com/ExE-Boss).
