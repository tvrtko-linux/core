#!/usr/bin/node
var argv = require('optimist')
    .boolean('v')
    .argv
;
console.dir(argv.v);
console.dir(argv._);
