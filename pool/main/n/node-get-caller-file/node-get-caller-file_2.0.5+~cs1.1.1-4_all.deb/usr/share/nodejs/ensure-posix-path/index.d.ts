declare const _default: (filepath: string) => string;
export = _default;
