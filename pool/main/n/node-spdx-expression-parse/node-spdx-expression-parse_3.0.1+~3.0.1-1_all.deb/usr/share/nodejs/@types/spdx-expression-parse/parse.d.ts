import { Info, Token } from './';

declare function parse(tokens: Token[]): Info;

export = parse;
