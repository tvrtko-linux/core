import { Token } from './';

declare function scan(source: string): Token[];

export = scan;
