export declare function stringify(o: any): string
export declare function parse(s: string): any
