const Parser = require('tap-parser')
const p = new Parser(results => console.dir(results))
process.stdin.pipe(p)
