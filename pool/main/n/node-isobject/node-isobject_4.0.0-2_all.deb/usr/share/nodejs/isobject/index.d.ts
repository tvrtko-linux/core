declare function isObject(val: any): boolean;

export default isObject;
