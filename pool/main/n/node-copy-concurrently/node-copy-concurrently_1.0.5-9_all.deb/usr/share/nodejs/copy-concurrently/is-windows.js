'use strict'
module.exports = process.platform === 'win32'
