import { stubString } from "../fp";
export = stubString;
