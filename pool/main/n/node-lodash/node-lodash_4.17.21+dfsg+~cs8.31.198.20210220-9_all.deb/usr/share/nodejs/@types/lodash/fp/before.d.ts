import { before } from "../fp";
export = before;
