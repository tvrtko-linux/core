import { runInContext } from "../fp";
export = runInContext;
