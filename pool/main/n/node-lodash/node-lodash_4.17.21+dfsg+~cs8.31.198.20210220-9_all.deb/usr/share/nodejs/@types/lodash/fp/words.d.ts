import { words } from "../fp";
export = words;
