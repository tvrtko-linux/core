import { trimCharsStart } from "../fp";
export = trimCharsStart;
