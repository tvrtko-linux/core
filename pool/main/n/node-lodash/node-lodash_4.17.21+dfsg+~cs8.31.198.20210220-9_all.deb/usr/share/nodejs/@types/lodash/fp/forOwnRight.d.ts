import { forOwnRight } from "../fp";
export = forOwnRight;
