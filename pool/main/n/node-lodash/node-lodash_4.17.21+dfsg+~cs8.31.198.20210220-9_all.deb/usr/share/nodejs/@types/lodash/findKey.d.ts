import { findKey } from "./index";
export = findKey;
