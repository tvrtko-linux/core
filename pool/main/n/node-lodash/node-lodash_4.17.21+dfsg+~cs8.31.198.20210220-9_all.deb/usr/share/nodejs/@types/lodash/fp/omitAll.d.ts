import { omitAll } from "../fp";
export = omitAll;
