import { all } from "../fp";
export = all;
