import { pullAllWith } from "../fp";
export = pullAllWith;
