import { last } from "../fp";
export = last;
