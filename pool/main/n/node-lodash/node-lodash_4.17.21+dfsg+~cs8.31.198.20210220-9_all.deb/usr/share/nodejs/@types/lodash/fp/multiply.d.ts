import { multiply } from "../fp";
export = multiply;
