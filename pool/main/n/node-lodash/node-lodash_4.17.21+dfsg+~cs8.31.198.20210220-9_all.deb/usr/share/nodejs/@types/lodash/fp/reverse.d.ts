import { reverse } from "../fp";
export = reverse;
