import { concat } from "../fp";
export = concat;
