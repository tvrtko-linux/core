import { stubFalse } from "../fp";
export = stubFalse;
