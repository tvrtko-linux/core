import { setWith } from "../fp";
export = setWith;
