import { stubArray } from "../fp";
export = stubArray;
