import { flatMapDeep } from "../fp";
export = flatMapDeep;
