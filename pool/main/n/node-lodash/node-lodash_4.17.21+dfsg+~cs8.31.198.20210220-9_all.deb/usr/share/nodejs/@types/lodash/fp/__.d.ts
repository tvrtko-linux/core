import _ = require("../index");
declare const __: _.__;
export = __;
