import { gt } from "../fp";
export = gt;
