import { pullAll } from "../fp";
export = pullAll;
