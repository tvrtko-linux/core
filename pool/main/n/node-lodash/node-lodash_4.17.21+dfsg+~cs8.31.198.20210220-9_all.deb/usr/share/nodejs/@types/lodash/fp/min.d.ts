import { min } from "../fp";
export = min;
