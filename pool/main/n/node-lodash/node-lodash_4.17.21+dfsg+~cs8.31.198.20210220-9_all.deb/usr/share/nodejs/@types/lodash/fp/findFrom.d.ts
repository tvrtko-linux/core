import { findFrom } from "../fp";
export = findFrom;
