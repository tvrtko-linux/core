import { ceil } from "../fp";
export = ceil;
