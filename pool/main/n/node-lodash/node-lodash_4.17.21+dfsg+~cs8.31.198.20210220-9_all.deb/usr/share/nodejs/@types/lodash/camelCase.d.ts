import { camelCase } from "./index";
export = camelCase;
