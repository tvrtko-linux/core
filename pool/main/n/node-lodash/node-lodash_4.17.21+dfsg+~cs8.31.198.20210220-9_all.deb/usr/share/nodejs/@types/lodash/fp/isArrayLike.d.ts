import { isArrayLike } from "../fp";
export = isArrayLike;
