import { countBy } from "../fp";
export = countBy;
