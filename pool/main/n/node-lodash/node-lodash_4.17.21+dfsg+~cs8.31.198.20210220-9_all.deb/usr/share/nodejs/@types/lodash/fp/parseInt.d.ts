import { parseInt } from "../fp";
export = parseInt;
