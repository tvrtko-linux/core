import { takeLastWhile } from "../fp";
export = takeLastWhile;
