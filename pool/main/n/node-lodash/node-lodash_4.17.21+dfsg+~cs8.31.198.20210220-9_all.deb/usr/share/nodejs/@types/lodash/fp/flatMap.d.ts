import { flatMap } from "../fp";
export = flatMap;
