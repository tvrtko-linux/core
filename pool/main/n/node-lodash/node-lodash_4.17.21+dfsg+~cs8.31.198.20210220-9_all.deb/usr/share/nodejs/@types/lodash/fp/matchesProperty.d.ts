import { matchesProperty } from "../fp";
export = matchesProperty;
