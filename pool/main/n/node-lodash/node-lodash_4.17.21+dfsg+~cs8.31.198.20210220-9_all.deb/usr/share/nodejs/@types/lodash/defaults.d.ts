import { defaults } from "./index";
export = defaults;
