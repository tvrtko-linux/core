import { filter } from "../fp";
export = filter;
