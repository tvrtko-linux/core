import { sampleSize } from "../fp";
export = sampleSize;
