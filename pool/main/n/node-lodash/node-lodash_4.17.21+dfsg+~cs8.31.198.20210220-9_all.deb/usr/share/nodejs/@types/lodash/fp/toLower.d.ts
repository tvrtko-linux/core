import { toLower } from "../fp";
export = toLower;
