import { flatMapDepth } from "../fp";
export = flatMapDepth;
