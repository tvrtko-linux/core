import { memoize } from "../fp";
export = memoize;
