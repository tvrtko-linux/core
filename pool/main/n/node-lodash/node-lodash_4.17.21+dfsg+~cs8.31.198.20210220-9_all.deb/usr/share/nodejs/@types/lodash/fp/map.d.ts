import { map } from "../fp";
export = map;
