import { padStart } from "../fp";
export = padStart;
