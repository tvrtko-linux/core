const m = require('./dhnodejsBundle.cjs');
m.get = m;
module.exports=m;
