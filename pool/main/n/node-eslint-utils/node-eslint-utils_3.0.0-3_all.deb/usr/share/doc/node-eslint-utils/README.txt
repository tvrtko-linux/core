eslint-utils

🏁 Goal

This package provides utility functions and classes for make ESLint custom rules.

For examples:

  - getStaticValue evaluates static value on AST.
  - ReferenceTracker checks the members of modules/globals as handling assignments and destructuring.

📖 Usage

See documentation.

📰 Changelog

See releases.

❤️ Contributing

Welcome contributing!

Please use GitHub's Issues/PRs.

Development Tools

  - npm test runs tests and measures coverage.
  - npm run clean removes the coverage result of npm test command.
  - npm run coverage shows the coverage result of the last npm test command.
  - npm run lint runs ESLint.
  - npm run watch runs tests on each file change.
