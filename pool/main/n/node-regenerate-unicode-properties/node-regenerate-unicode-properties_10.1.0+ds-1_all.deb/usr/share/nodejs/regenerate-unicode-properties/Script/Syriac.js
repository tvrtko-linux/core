const set = require('regenerate')();
set.addRange(0x700, 0x70D).addRange(0x70F, 0x74A).addRange(0x74D, 0x74F).addRange(0x860, 0x86A);
exports.characters = set;
