const set = require('regenerate')();
set.addRange(0x11150, 0x11176);
exports.characters = set;
