const set = require('regenerate')(0xA92F);
set.addRange(0xA900, 0xA92D);
exports.characters = set;
