const set = require('regenerate')();
set.addRange(0x13000, 0x13455);
exports.characters = set;
