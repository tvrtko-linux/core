const set = require('regenerate')(0x1093F);
set.addRange(0x10920, 0x10939);
exports.characters = set;
