module.exports = require('./lib/repl.js');
