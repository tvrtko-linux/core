# Installation
> `npm install --save @types/is-ci`

# Summary
This package contains type definitions for is-ci (https://github.com/watson/is-ci).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/is-ci.

### Additional Details
 * Last updated: Sun, 07 Mar 2021 11:48:45 GMT
 * Dependencies: [@types/ci-info](https://npmjs.com/package/@types/ci-info)
 * Global values: none

# Credits
These definitions were written by [Arne Schubert](https://github.com/atd-schubert), and [Florian Imdahl](https://github.com/ffflorian).
