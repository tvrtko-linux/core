# Installation
> `npm install --save @types/resolve`

# Summary
This package contains type definitions for resolve (https://github.com/browserify/resolve).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/resolve.

### Additional Details
 * Last updated: Thu, 21 Apr 2022 18:01:43 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Mario Nebl](https://github.com/marionebl), [Klaus Meinhardt](https://github.com/ajafff), and [Jordan Harband](https://github.com/ljharb).
