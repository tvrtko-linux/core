import TimeWithinDay = require('../2017/TimeWithinDay');
export = TimeWithinDay;
