import RegExpExec = require('../2015/RegExpExec');
export = RegExpExec;
