import YearFromTime = require('../2015/YearFromTime');
export = YearFromTime;
