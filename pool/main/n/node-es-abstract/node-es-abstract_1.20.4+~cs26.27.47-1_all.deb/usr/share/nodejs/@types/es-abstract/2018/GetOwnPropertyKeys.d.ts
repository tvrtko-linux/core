import GetOwnPropertyKeys = require('../2017/GetOwnPropertyKeys');
export = GetOwnPropertyKeys;
