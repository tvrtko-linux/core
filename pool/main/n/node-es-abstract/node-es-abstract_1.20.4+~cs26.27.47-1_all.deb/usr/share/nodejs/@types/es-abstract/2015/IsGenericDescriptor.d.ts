import IsGenericDescriptor = require('../5/IsGenericDescriptor');
export = IsGenericDescriptor;
