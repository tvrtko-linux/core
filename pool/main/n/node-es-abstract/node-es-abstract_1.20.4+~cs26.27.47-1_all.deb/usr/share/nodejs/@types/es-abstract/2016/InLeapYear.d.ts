import InLeapYear = require('../2015/InLeapYear');
export = InLeapYear;
