import ToInt8 = require('../2016/ToInt8');
export = ToInt8;
