import thisTimeValue = require('../2017/thisTimeValue');
export = thisTimeValue;
