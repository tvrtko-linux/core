declare function ToInt16(value: unknown): number;
export = ToInt16;
