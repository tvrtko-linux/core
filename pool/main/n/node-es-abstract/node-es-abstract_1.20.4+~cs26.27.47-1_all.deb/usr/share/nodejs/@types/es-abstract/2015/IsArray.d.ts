declare const IsArray: typeof Array.isArray;
export = IsArray;
