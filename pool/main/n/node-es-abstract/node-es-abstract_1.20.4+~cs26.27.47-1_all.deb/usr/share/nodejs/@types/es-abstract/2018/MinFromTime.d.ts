import MinFromTime = require('../2017/MinFromTime');
export = MinFromTime;
