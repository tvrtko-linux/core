declare function ToInt8(value: unknown): number;
export = ToInt8;
