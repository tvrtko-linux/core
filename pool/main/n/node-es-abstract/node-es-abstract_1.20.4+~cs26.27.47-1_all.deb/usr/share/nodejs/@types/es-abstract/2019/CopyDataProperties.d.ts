import CopyDataProperties = require('../2018/CopyDataProperties');
export = CopyDataProperties;
