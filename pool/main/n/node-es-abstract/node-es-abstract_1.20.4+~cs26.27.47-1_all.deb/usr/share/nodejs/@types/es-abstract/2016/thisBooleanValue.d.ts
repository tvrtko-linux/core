import thisBooleanValue = require('../2015/thisBooleanValue');
export = thisBooleanValue;
