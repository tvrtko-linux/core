import ToUint32 = require('../2017/ToUint32');
export = ToUint32;
