import InLeapYear = require('../2016/InLeapYear');
export = InLeapYear;
