import ToObject = require('../2015/ToObject');
export = ToObject;
