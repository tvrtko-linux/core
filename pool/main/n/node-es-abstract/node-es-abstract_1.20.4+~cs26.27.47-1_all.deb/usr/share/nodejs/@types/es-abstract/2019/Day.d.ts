import Day = require('../2018/Day');
export = Day;
