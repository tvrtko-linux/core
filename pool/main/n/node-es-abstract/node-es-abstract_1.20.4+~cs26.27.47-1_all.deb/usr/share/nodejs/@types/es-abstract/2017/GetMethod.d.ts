import GetMethod = require('../2016/GetMethod');
export = GetMethod;
