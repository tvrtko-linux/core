import ObjectCreate = require('../2017/ObjectCreate');
export = ObjectCreate;
