import WeekDay = require('../2015/WeekDay');
export = WeekDay;
