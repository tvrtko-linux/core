import AdvanceStringIndex = require('../2018/AdvanceStringIndex');
export = AdvanceStringIndex;
