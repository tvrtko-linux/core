import IsConstructor = require('../2015/IsConstructor');
export = IsConstructor;
