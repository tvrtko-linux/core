import ArraySpeciesCreate = require('../2017/ArraySpeciesCreate');
export = ArraySpeciesCreate;
