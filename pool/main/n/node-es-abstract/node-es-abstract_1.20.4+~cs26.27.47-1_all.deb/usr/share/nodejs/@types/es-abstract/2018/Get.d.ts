import Get = require('../2017/Get');
export = Get;
