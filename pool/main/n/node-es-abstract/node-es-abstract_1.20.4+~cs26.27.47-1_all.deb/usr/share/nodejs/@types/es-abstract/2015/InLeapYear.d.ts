import InLeapYear = require('../5/InLeapYear');
export = InLeapYear;
