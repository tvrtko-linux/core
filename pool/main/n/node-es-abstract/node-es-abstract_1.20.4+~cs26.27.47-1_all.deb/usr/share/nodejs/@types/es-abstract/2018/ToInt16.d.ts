import ToInt16 = require('../2017/ToInt16');
export = ToInt16;
