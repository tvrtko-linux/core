import DefinePropertyOrThrow = require('../2018/DefinePropertyOrThrow');
export = DefinePropertyOrThrow;
