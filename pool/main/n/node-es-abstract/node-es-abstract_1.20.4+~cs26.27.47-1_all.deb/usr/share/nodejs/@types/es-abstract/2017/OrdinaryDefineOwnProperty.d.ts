import OrdinaryDefineOwnProperty = require('../2016/OrdinaryDefineOwnProperty');
export = OrdinaryDefineOwnProperty;
