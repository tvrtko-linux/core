import AbstractRelationalComparison = require('../2017/AbstractRelationalComparison');
export = AbstractRelationalComparison;
