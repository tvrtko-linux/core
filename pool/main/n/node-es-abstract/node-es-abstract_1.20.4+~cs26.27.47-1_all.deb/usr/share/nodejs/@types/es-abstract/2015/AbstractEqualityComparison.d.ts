import AbstractEqualityComparison = require('../5/AbstractEqualityComparison');
export = AbstractEqualityComparison;
