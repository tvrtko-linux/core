declare function GetSubstitution(
    matched: string,
    str: string,
    position: number,
    captures: string[],
    replacement: string,
): string;
export = GetSubstitution;
