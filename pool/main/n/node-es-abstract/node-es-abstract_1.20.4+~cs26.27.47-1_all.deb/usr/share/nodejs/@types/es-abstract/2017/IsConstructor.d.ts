import IsConstructor = require('../2016/IsConstructor');
export = IsConstructor;
