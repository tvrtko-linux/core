import GetPrototypeFromConstructor = require('../2015/GetPrototypeFromConstructor');
export = GetPrototypeFromConstructor;
