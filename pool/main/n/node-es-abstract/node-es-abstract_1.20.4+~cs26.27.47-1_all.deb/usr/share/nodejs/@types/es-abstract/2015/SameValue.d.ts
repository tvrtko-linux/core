import SameValue = require('../5/SameValue');
export = SameValue;
