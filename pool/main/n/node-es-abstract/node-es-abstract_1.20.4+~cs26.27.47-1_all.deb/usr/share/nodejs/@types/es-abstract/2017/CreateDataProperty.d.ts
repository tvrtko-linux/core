import CreateDataProperty = require('../2016/CreateDataProperty');
export = CreateDataProperty;
