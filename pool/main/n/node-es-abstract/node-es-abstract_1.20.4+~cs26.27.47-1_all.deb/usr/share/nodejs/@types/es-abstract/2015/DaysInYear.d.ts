import DaysInYear = require('../5/DaysInYear');
export = DaysInYear;
