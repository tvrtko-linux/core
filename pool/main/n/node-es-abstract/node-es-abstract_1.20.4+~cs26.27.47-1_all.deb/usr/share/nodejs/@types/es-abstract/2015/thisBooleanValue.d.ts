// tslint:disable-next-line: ban-types
declare function thisBooleanValue(value: boolean | Boolean): boolean;
export = thisBooleanValue;
