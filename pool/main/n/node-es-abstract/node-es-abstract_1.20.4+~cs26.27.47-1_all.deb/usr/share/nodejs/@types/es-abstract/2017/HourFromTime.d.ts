import HourFromTime = require('../2016/HourFromTime');
export = HourFromTime;
