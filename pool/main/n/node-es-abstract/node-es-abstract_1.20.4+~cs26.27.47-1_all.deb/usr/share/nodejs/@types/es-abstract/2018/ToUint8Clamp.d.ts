import ToUint8Clamp = require('../2017/ToUint8Clamp');
export = ToUint8Clamp;
