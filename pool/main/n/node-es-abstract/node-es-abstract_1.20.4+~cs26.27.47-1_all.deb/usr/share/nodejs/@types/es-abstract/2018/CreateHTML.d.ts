import CreateHTML = require('../2017/CreateHTML');
export = CreateHTML;
