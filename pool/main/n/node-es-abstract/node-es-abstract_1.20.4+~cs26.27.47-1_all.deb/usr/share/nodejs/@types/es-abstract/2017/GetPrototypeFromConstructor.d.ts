import GetPrototypeFromConstructor = require('../2016/GetPrototypeFromConstructor');
export = GetPrototypeFromConstructor;
