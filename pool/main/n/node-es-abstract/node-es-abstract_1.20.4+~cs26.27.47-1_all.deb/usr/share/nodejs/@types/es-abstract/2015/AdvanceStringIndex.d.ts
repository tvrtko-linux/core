declare function AdvanceStringIndex(S: string, index: number, unicode: boolean): number;
export = AdvanceStringIndex;
