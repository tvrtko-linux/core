import Get = require('../2018/Get');
export = Get;
