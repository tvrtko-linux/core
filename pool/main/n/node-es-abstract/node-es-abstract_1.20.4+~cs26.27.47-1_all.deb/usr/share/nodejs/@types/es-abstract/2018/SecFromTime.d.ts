import SecFromTime = require('../2017/SecFromTime');
export = SecFromTime;
