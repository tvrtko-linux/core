import ToUint8 = require('../2016/ToUint8');
export = ToUint8;
