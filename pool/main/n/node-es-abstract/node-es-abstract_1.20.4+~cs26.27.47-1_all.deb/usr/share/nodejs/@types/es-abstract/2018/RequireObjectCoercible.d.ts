import RequireObjectCoercible = require('../2017/RequireObjectCoercible');
export = RequireObjectCoercible;
