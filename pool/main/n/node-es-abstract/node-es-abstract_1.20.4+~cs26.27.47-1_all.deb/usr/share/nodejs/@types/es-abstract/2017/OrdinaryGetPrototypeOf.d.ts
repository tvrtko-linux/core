import OrdinaryGetPrototypeOf = require('../2016/OrdinaryGetPrototypeOf');
export = OrdinaryGetPrototypeOf;
