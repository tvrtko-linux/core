import AdvanceStringIndex = require('../2017/AdvanceStringIndex');
export = AdvanceStringIndex;
