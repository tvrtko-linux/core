import GetMethod = require('../2017/GetMethod');
export = GetMethod;
