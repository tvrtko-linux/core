import HasProperty = require('../2017/HasProperty');
export = HasProperty;
