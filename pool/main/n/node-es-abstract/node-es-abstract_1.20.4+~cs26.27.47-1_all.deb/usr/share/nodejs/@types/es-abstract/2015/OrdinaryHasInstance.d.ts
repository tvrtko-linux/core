declare function OrdinaryHasInstance(C: unknown, O: object): boolean;
export = OrdinaryHasInstance;
