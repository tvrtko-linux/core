import CreateHTML = require('../2016/CreateHTML');
export = CreateHTML;
