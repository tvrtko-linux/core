import thisNumberValue = require('../2017/thisNumberValue');
export = thisNumberValue;
