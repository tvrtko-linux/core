import ToString = require('../2015/ToString');
export = ToString;
