import MinFromTime = require('../2015/MinFromTime');
export = MinFromTime;
