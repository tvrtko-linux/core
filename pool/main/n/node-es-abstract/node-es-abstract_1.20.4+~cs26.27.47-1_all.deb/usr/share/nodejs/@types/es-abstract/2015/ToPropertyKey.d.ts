declare function ToPropertyKey(value: unknown): PropertyKey;
export = ToPropertyKey;
