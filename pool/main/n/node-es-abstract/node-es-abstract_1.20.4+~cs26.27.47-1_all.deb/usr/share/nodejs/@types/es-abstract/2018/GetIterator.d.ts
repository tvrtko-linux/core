import GetIterator = require('../2017/GetIterator');
export = GetIterator;
