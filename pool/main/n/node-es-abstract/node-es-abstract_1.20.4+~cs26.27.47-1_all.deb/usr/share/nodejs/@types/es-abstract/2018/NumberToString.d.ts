declare function NumberToString(m: number): string;
export = NumberToString;
