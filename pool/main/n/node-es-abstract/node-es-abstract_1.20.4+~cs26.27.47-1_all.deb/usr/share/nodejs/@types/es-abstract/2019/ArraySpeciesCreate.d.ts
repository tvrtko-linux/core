import ArraySpeciesCreate = require('../2018/ArraySpeciesCreate');
export = ArraySpeciesCreate;
