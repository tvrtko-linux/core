import ToPrimitive = require('../2015/ToPrimitive');
export = ToPrimitive;
