import MakeDay = require('../2015/MakeDay');
export = MakeDay;
