import MonthFromTime = require('../2016/MonthFromTime');
export = MonthFromTime;
