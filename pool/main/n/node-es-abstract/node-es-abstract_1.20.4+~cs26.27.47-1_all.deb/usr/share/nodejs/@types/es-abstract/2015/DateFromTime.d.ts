import DateFromTime = require('../5/DateFromTime');
export = DateFromTime;
