import WeekDay = require('../2017/WeekDay');
export = WeekDay;
