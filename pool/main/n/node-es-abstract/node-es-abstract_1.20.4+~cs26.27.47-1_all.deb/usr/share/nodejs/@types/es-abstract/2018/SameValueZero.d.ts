import SameValueZero = require('../2017/SameValueZero');
export = SameValueZero;
