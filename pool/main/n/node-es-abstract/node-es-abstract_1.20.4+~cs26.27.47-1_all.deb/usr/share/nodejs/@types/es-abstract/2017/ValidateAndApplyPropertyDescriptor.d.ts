import ValidateAndApplyPropertyDescriptor = require('../2016/ValidateAndApplyPropertyDescriptor');
export = ValidateAndApplyPropertyDescriptor;
