import StrictEqualityComparison = require('../2015/StrictEqualityComparison');
export = StrictEqualityComparison;
