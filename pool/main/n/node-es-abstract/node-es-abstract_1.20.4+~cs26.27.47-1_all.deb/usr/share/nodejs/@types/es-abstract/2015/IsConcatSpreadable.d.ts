declare function IsConcatSpreadable(O: object): O is ConcatArray<any>;
export = IsConcatSpreadable;
