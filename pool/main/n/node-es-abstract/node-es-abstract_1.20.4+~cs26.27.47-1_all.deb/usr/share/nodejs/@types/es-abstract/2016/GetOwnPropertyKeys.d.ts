import GetOwnPropertyKeys = require('../2015/GetOwnPropertyKeys');
export = GetOwnPropertyKeys;
