import IteratorNext = require('../2015/IteratorNext');
export = IteratorNext;
