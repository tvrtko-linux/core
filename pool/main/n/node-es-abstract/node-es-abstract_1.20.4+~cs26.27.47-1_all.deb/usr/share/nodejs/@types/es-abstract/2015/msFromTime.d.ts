import msFromTime = require('../5/msFromTime');
export = msFromTime;
