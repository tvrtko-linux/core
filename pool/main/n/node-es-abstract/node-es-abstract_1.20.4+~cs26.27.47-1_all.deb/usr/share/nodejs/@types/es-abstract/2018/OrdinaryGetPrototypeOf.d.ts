import OrdinaryGetPrototypeOf = require('../2017/OrdinaryGetPrototypeOf');
export = OrdinaryGetPrototypeOf;
