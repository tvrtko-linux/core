import SecFromTime = require('../5/SecFromTime');
export = SecFromTime;
