import CreateMethodProperty = require('../2015/CreateMethodProperty');
export = CreateMethodProperty;
