import FromPropertyDescriptor = require('../5/FromPropertyDescriptor');
export = FromPropertyDescriptor;
