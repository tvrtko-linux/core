declare function SymbolDescriptiveString(sym: symbol): string;
export = SymbolDescriptiveString;
