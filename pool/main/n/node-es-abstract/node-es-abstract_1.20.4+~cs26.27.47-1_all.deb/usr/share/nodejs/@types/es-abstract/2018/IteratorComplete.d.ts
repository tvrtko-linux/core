import IteratorComplete = require('../2017/IteratorComplete');
export = IteratorComplete;
