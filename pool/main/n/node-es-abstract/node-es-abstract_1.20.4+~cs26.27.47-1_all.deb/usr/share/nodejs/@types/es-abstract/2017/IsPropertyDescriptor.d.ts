import IsPropertyDescriptor = require('../2016/IsPropertyDescriptor');
export = IsPropertyDescriptor;
