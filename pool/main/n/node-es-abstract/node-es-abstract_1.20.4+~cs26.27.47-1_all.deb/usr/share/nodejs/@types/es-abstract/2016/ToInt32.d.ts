import ToInt32 = require('../2015/ToInt32');
export = ToInt32;
