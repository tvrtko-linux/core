import ArraySetLength = require('../2015/ArraySetLength');
export = ArraySetLength;
