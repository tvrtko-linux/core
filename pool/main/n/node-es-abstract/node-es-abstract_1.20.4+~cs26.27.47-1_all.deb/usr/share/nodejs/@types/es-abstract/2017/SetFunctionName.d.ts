import SetFunctionName = require('../2016/SetFunctionName');
export = SetFunctionName;
