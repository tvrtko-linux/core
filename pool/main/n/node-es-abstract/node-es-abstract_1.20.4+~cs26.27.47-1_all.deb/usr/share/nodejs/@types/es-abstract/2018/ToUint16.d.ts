import ToUint16 = require('../2017/ToUint16');
export = ToUint16;
