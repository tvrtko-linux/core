import IsConcatSpreadable = require('../2018/IsConcatSpreadable');
export = IsConcatSpreadable;
