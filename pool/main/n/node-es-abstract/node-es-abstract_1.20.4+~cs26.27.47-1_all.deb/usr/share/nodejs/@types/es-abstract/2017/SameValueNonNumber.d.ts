import SameValueNonNumber = require('../2016/SameValueNonNumber');
export = SameValueNonNumber;
