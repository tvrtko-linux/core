import CreateListFromArrayLike = require('../2018/CreateListFromArrayLike');
export = CreateListFromArrayLike;
