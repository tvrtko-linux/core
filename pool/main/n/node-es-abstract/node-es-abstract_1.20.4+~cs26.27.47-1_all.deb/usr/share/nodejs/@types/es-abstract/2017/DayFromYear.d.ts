import DayFromYear = require('../2016/DayFromYear');
export = DayFromYear;
