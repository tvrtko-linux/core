import modulo = require('../2015/modulo');
export = modulo;
