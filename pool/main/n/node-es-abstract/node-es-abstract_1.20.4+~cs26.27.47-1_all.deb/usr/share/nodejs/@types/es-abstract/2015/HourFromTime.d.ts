import HourFromTime = require('../5/HourFromTime');
export = HourFromTime;
