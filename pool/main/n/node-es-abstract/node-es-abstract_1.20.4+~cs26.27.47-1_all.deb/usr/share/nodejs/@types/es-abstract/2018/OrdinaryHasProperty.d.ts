import OrdinaryHasProperty = require('../2017/OrdinaryHasProperty');
export = OrdinaryHasProperty;
