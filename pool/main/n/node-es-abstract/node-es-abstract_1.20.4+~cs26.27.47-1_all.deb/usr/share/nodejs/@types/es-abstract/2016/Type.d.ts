import Type = require('../2015/Type');
export = Type;
