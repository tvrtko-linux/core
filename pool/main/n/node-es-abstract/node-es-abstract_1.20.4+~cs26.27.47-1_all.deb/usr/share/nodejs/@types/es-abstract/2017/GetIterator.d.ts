import GetIterator = require('../2016/GetIterator');
export = GetIterator;
