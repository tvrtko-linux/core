import WeekDay = require('../5/WeekDay');
export = WeekDay;
