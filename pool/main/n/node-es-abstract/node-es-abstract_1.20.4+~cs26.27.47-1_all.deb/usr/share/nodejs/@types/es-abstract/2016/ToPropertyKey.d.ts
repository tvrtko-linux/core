import ToPropertyKey = require('../2015/ToPropertyKey');
export = ToPropertyKey;
