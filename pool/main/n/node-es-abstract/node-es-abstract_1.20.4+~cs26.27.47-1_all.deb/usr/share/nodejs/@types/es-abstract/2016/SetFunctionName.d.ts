import SetFunctionName = require('../2015/SetFunctionName');
export = SetFunctionName;
