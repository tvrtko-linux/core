import RequireObjectCoercible = require('../2016/RequireObjectCoercible');
export = RequireObjectCoercible;
