import HasProperty = require('../2016/HasProperty');
export = HasProperty;
