import ToIndex = require('../2017/ToIndex');
export = ToIndex;
