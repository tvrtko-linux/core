import RegExpExec = require('../2016/RegExpExec');
export = RegExpExec;
