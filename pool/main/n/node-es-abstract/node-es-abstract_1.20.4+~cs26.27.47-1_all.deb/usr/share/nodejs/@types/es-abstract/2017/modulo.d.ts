import modulo = require('../2016/modulo');
export = modulo;
