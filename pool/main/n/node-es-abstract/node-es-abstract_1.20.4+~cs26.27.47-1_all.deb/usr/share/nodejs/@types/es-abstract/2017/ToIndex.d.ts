declare function ToIndex(value: unknown): number;
export = ToIndex;
