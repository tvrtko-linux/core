import TimeFromYear = require('../2016/TimeFromYear');
export = TimeFromYear;
