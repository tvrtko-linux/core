declare function thisTimeValue(value: Date): number;
export = thisTimeValue;
