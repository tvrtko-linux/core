import SpeciesConstructor = require('../2015/SpeciesConstructor');
export = SpeciesConstructor;
