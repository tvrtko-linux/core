import IsDataDescriptor = require('../2015/IsDataDescriptor');
export = IsDataDescriptor;
