import ToObject = require('../2017/ToObject');
export = ToObject;
