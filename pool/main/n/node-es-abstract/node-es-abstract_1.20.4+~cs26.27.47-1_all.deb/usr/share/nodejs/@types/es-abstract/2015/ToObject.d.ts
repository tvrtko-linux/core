import ToObject = require('../5/ToObject');
export = ToObject;
