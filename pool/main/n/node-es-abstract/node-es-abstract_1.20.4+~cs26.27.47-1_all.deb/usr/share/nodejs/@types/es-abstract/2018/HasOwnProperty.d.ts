import HasOwnProperty = require('../2017/HasOwnProperty');
export = HasOwnProperty;
