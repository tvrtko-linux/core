import HasOwnProperty = require('../2016/HasOwnProperty');
export = HasOwnProperty;
