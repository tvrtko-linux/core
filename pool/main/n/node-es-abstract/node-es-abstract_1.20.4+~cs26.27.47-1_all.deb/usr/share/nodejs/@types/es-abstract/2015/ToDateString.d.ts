declare function ToDateString(tv: number): string;
export = ToDateString;
