import IsCallable = require('../2016/IsCallable');
export = IsCallable;
