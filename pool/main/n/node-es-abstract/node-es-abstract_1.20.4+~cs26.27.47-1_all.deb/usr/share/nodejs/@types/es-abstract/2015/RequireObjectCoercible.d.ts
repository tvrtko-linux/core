import RequireObjectCoercible = require('../5/CheckObjectCoercible');
export = RequireObjectCoercible;
