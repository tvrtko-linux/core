import ToUint32 = require('../2016/ToUint32');
export = ToUint32;
