declare function ToUint8Clamp(value: unknown): number;
export = ToUint8Clamp;
