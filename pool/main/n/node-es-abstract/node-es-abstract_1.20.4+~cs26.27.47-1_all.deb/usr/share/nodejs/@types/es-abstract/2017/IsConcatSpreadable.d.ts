import IsConcatSpreadable = require('../2016/IsConcatSpreadable');
export = IsConcatSpreadable;
