import thisTimeValue = require('../2016/thisTimeValue');
export = thisTimeValue;
