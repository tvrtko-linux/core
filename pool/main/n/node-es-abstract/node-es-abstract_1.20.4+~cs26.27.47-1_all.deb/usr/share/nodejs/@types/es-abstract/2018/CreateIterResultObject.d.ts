import CreateIterResultObject = require('../2017/CreateIterResultObject');
export = CreateIterResultObject;
