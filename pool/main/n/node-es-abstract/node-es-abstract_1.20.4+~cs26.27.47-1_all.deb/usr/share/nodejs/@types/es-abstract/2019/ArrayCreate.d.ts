import ArrayCreate = require('../2018/ArrayCreate');
export = ArrayCreate;
