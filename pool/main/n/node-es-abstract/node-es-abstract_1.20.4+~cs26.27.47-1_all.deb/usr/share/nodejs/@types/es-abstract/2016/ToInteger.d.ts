import ToInteger = require('../2015/ToInteger');
export = ToInteger;
