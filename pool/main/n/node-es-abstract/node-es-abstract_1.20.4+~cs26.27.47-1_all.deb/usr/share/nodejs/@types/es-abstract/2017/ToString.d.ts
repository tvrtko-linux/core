import ToString = require('../2016/ToString');
export = ToString;
