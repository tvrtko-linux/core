import msFromTime = require('../2017/msFromTime');
export = msFromTime;
