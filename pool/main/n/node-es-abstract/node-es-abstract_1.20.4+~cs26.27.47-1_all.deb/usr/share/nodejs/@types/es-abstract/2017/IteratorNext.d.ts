import IteratorNext = require('../2016/IteratorNext');
export = IteratorNext;
