import StrictEqualityComparison = require('../5/StrictEqualityComparison');
export = StrictEqualityComparison;
