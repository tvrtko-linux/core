import FromPropertyDescriptor = require('../2017/FromPropertyDescriptor');
export = FromPropertyDescriptor;
