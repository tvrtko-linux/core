import CreateListFromArrayLike = require('../2016/CreateListFromArrayLike');
export = CreateListFromArrayLike;
