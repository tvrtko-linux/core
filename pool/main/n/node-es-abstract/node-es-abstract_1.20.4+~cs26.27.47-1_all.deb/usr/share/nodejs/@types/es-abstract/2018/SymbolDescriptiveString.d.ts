import SymbolDescriptiveString = require('../2017/SymbolDescriptiveString');
export = SymbolDescriptiveString;
