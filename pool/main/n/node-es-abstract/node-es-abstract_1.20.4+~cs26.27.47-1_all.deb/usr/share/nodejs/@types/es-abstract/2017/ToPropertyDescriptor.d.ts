import ToPropertyDescriptor = require('../2016/ToPropertyDescriptor');
export = ToPropertyDescriptor;
