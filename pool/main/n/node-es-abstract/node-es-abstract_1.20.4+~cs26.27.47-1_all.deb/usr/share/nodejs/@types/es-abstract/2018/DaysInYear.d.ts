import DaysInYear = require('../2017/DaysInYear');
export = DaysInYear;
