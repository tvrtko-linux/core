import GetPrototypeFromConstructor = require('../2018/GetPrototypeFromConstructor');
export = GetPrototypeFromConstructor;
