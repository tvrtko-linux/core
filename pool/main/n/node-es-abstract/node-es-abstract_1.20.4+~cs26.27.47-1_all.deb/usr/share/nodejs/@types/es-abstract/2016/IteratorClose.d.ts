import IteratorClose = require('../2015/IteratorClose');
export = IteratorClose;
