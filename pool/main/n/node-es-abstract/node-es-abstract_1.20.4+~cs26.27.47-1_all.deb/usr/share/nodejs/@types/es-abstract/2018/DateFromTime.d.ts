import DateFromTime = require('../2017/DateFromTime');
export = DateFromTime;
