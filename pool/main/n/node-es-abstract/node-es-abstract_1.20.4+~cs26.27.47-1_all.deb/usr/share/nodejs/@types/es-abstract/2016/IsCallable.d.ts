import IsCallable = require('../2015/IsCallable');
export = IsCallable;
