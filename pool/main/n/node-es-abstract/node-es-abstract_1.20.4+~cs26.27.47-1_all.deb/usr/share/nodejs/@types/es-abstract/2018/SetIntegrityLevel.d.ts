import SetIntegrityLevel = require('../2017/SetIntegrityLevel');
export = SetIntegrityLevel;
