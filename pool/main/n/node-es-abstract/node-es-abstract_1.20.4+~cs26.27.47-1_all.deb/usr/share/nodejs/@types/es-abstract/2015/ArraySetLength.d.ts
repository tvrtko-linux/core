import type { PropertyDescriptor } from '../index';

declare function ArraySetLength(A: unknown[], Desc: PropertyDescriptor): boolean;
export = ArraySetLength;
