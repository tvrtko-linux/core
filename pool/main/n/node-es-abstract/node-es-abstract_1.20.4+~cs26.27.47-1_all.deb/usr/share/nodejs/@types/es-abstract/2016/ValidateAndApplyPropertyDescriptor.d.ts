import ValidateAndApplyPropertyDescriptor = require('../2015/ValidateAndApplyPropertyDescriptor');
export = ValidateAndApplyPropertyDescriptor;
