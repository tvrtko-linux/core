import ArraySpeciesCreate = require('../2016/ArraySpeciesCreate');
export = ArraySpeciesCreate;
