import RegExpExec = require('../2017/RegExpExec');
export = RegExpExec;
