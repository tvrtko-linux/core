import GetV = require('../2018/GetV');
export = GetV;
