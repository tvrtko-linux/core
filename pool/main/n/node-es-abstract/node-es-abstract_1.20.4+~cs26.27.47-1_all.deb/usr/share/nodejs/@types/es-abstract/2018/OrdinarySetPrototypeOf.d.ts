import OrdinarySetPrototypeOf = require('../2017/OrdinarySetPrototypeOf');
export = OrdinarySetPrototypeOf;
