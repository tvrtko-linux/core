import TimeFromYear = require('../5/TimeFromYear');
export = TimeFromYear;
