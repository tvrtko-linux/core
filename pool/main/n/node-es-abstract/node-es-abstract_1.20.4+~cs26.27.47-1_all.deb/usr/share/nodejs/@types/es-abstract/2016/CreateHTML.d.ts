import CreateHTML = require('../2015/CreateHTML');
export = CreateHTML;
