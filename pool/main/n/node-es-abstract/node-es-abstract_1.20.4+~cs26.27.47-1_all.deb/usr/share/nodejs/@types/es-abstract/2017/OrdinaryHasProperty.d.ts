import OrdinaryHasProperty = require('../2016/OrdinaryHasProperty');
export = OrdinaryHasProperty;
