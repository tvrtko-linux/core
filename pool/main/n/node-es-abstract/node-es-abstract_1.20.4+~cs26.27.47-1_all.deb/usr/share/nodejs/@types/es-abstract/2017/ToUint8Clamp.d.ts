import ToUint8Clamp = require('../2016/ToUint8Clamp');
export = ToUint8Clamp;
