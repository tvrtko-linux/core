import IsAccessorDescriptor = require('../5/IsAccessorDescriptor');
export = IsAccessorDescriptor;
