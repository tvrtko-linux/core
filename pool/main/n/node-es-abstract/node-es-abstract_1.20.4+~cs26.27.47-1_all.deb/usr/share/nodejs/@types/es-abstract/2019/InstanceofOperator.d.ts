import InstanceofOperator = require('../2018/InstanceofOperator');
export = InstanceofOperator;
