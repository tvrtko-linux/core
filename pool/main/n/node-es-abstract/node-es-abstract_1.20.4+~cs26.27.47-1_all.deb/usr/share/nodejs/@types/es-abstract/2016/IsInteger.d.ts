import IsInteger = require('../2015/IsInteger');
export = IsInteger;
