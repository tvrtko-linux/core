import Invoke = require('../2016/Invoke');
export = Invoke;
