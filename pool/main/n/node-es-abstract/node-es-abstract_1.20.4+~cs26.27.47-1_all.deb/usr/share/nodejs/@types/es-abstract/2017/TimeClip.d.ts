import TimeClip = require('../2016/TimeClip');
export = TimeClip;
