import GetSubstitution = require('../2015/GetSubstitution');
export = GetSubstitution;
