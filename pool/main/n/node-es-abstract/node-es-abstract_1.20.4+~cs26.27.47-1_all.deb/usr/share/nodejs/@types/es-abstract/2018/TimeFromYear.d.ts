import TimeFromYear = require('../2017/TimeFromYear');
export = TimeFromYear;
