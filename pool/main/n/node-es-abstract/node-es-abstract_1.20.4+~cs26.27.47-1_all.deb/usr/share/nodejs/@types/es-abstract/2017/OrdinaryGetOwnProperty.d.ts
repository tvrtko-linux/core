import OrdinaryGetOwnProperty = require('../2016/OrdinaryGetOwnProperty');
export = OrdinaryGetOwnProperty;
