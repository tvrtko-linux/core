import msFromTime = require('../2015/msFromTime');
export = msFromTime;
