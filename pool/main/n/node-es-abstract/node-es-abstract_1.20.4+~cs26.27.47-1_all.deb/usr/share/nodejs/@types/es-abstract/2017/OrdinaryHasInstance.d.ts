import OrdinaryHasInstance = require('../2016/OrdinaryHasInstance');
export = OrdinaryHasInstance;
