import ToPrimitive = require('../2016/ToPrimitive');
export = ToPrimitive;
