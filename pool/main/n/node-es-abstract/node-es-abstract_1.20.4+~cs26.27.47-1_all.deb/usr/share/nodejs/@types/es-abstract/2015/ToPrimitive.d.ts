import ToPrimitive = require('es-to-primitive/es2015');
export = ToPrimitive;
