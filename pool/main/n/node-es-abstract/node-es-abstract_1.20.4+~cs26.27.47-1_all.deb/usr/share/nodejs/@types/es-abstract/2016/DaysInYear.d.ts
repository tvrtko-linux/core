import DaysInYear = require('../2015/DaysInYear');
export = DaysInYear;
