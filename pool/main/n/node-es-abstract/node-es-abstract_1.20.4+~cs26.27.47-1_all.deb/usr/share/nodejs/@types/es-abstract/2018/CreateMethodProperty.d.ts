import CreateMethodProperty = require('../2017/CreateMethodProperty');
export = CreateMethodProperty;
