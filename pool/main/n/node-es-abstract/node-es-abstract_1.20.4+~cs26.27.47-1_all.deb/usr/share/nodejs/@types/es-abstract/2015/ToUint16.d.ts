import ToUint16 = require('../5/ToUint16');
export = ToUint16;
