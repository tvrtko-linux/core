import CreateDataPropertyOrThrow = require('../2015/CreateDataPropertyOrThrow');
export = CreateDataPropertyOrThrow;
