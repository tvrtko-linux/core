import ToPrimitive = require('../2017/ToPrimitive');
export = ToPrimitive;
