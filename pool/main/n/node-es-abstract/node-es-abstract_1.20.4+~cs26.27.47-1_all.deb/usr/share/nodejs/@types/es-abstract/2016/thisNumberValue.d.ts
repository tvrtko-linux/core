import thisNumberValue = require('../2015/thisNumberValue');
export = thisNumberValue;
