import ToString = require('../2017/ToString');
export = ToString;
