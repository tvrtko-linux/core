import IsGenericDescriptor = require('../2015/IsGenericDescriptor');
export = IsGenericDescriptor;
