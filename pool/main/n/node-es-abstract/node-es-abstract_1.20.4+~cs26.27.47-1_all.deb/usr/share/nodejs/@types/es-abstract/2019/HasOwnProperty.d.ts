import HasOwnProperty = require('../2018/HasOwnProperty');
export = HasOwnProperty;
