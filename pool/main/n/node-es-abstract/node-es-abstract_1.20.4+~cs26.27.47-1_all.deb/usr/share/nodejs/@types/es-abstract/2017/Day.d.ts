import Day = require('../2016/Day');
export = Day;
