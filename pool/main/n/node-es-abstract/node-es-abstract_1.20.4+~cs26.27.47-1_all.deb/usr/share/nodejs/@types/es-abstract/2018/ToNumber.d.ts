import ToNumber = require('../2017/ToNumber');
export = ToNumber;
