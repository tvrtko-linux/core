declare function OrdinarySetPrototypeOf(O: object, V: object | null): boolean;
export = OrdinarySetPrototypeOf;
