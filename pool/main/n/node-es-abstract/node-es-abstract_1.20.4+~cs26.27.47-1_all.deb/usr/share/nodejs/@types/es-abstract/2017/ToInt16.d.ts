import ToInt16 = require('../2016/ToInt16');
export = ToInt16;
