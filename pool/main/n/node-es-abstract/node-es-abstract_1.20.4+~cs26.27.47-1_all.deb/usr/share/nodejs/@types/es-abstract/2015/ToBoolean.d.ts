import ToBoolean = require('../5/ToBoolean');
export = ToBoolean;
