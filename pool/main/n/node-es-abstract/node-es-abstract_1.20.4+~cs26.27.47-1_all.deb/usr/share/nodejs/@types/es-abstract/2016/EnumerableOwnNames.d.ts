import EnumerableOwnNames = require('../2015/EnumerableOwnNames');
export = EnumerableOwnNames;
