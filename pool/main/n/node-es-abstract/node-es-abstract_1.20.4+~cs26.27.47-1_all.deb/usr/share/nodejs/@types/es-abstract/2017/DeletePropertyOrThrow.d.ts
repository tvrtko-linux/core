import DeletePropertyOrThrow = require('../2016/DeletePropertyOrThrow');
export = DeletePropertyOrThrow;
