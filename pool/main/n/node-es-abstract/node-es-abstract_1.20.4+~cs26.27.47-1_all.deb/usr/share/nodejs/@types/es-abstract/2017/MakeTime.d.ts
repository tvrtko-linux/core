import MakeTime = require('../2016/MakeTime');
export = MakeTime;
