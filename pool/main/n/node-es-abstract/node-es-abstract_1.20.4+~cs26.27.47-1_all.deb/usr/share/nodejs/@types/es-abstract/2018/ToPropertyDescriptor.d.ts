import ToPropertyDescriptor = require('../2017/ToPropertyDescriptor');
export = ToPropertyDescriptor;
