import FromPropertyDescriptor = require('../2018/FromPropertyDescriptor');
export = FromPropertyDescriptor;
