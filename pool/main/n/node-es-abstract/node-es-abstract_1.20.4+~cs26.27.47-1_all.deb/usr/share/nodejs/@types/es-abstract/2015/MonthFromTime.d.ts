import MonthFromTime = require('../5/MonthFromTime');
export = MonthFromTime;
