import CanonicalNumericIndexString = require('../2017/CanonicalNumericIndexString');
export = CanonicalNumericIndexString;
