import DayFromYear = require('../2017/DayFromYear');
export = DayFromYear;
