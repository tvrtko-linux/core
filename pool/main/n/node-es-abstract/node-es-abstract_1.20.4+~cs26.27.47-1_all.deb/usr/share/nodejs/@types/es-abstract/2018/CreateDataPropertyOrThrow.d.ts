import CreateDataPropertyOrThrow = require('../2017/CreateDataPropertyOrThrow');
export = CreateDataPropertyOrThrow;
