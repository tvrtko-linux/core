import ToPropertyKey = require('../2017/ToPropertyKey');
export = ToPropertyKey;
