import modulo = require('../5/modulo');
export = modulo;
