import ToInteger = require('../2017/ToInteger');
export = ToInteger;
