import OrdinarySetPrototypeOf = require('../2016/OrdinarySetPrototypeOf');
export = OrdinarySetPrototypeOf;
