import GetSubstitution = require('../2016/GetSubstitution');
export = GetSubstitution;
