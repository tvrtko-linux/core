import OrdinaryGetOwnProperty = require('../2017/OrdinaryGetOwnProperty');
export = OrdinaryGetOwnProperty;
