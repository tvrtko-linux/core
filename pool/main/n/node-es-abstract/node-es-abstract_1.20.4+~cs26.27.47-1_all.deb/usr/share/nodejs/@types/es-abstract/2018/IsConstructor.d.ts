import IsConstructor = require('../2017/IsConstructor');
export = IsConstructor;
