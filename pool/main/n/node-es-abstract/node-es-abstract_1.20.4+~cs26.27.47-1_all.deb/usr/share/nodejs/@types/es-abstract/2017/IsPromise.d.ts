import IsPromise = require('../2016/IsPromise');
export = IsPromise;
