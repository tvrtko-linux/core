import Day = require('../2017/Day');
export = Day;
