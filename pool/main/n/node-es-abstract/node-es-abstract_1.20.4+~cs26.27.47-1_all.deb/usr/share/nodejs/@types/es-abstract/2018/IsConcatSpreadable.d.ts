import IsConcatSpreadable = require('../2017/IsConcatSpreadable');
export = IsConcatSpreadable;
