import TimeWithinDay = require('../2015/TimeWithinDay');
export = TimeWithinDay;
