declare function CanonicalNumericIndexString(value: string): number | undefined;
export = CanonicalNumericIndexString;
