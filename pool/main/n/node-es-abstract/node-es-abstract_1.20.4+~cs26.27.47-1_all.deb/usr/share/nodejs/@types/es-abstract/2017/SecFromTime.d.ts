import SecFromTime = require('../2016/SecFromTime');
export = SecFromTime;
