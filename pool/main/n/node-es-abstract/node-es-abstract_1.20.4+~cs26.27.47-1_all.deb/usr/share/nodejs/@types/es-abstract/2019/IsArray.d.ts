import IsArray = require('../2018/IsArray');
export = IsArray;
