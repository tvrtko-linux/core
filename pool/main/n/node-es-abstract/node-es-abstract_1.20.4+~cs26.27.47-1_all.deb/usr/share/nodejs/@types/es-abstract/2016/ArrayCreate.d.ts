import ArrayCreate = require('../2015/ArrayCreate');
export = ArrayCreate;
