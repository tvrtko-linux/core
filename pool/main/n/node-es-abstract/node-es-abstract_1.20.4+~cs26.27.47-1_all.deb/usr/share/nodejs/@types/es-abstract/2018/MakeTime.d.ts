import MakeTime = require('../2017/MakeTime');
export = MakeTime;
