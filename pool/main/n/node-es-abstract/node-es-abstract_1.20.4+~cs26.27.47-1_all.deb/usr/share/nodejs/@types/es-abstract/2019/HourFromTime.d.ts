import HourFromTime = require('../2018/HourFromTime');
export = HourFromTime;
