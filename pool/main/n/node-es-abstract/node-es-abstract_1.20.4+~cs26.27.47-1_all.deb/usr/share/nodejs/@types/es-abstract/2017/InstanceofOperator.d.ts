import InstanceofOperator = require('../2016/InstanceofOperator');
export = InstanceofOperator;
