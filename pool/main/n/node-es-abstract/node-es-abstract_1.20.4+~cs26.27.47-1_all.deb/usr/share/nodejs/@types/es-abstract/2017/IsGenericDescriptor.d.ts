import IsGenericDescriptor = require('../2016/IsGenericDescriptor');
export = IsGenericDescriptor;
