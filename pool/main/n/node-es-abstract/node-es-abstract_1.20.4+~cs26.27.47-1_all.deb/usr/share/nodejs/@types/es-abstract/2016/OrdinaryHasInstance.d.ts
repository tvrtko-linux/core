import OrdinaryHasInstance = require('../2015/OrdinaryHasInstance');
export = OrdinaryHasInstance;
