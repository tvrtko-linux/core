import GetOwnPropertyKeys = require('../2018/GetOwnPropertyKeys');
export = GetOwnPropertyKeys;
