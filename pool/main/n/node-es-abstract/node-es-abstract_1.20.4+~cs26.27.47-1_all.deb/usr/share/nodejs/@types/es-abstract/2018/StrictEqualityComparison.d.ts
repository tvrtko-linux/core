import StrictEqualityComparison = require('../2017/StrictEqualityComparison');
export = StrictEqualityComparison;
