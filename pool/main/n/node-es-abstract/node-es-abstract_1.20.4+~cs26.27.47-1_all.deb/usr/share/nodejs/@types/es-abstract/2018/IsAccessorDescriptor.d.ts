import IsAccessorDescriptor = require('../2017/IsAccessorDescriptor');
export = IsAccessorDescriptor;
