import IsInteger = require('../2016/IsInteger');
export = IsInteger;
