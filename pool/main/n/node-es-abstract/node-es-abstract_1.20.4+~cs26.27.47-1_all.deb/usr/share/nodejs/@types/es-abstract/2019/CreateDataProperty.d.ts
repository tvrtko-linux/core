import CreateDataProperty = require('../2018/CreateDataProperty');
export = CreateDataProperty;
