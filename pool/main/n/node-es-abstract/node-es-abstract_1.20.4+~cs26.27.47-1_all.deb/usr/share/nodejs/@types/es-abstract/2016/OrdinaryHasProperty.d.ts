import OrdinaryHasProperty = require('../2015/OrdinaryHasProperty');
export = OrdinaryHasProperty;
