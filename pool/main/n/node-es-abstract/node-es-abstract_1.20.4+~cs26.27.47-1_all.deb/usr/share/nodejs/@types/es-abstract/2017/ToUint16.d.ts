import ToUint16 = require('../2016/ToUint16');
export = ToUint16;
