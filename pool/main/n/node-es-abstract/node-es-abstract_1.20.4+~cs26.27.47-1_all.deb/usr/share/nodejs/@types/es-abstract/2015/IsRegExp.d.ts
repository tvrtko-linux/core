declare function IsRegExp(argument: unknown): argument is RegExp;
export = IsRegExp;
