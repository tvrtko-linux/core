import AbstractRelationalComparison = require('../2015/AbstractRelationalComparison');
export = AbstractRelationalComparison;
