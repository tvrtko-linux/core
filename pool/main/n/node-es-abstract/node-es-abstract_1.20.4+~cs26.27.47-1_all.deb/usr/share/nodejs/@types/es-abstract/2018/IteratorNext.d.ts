import IteratorNext = require('../2017/IteratorNext');
export = IteratorNext;
