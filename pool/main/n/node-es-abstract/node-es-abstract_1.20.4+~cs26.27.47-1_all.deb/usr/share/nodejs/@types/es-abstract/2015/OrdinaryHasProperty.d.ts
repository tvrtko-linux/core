declare function OrdinaryHasProperty(O: object, P: PropertyKey): boolean;
export = OrdinaryHasProperty;
