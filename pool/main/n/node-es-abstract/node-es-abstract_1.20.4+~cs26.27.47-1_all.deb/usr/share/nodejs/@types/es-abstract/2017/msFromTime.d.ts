import msFromTime = require('../2016/msFromTime');
export = msFromTime;
