import AdvanceStringIndex = require('../2016/AdvanceStringIndex');
export = AdvanceStringIndex;
