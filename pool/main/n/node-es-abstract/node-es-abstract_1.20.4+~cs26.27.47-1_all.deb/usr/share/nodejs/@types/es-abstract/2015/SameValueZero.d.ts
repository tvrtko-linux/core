declare function SameValueZero(x: unknown, y: unknown): boolean;
export = SameValueZero;
