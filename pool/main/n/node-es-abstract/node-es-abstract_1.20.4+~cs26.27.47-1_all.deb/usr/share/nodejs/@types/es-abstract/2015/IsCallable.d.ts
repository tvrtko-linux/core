import IsCallable = require('../5/IsCallable');
export = IsCallable;
