import OrdinaryGetOwnProperty = require('../2015/OrdinaryGetOwnProperty');
export = OrdinaryGetOwnProperty;
