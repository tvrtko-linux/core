import CreateDataProperty = require('../2017/CreateDataProperty');
export = CreateDataProperty;
