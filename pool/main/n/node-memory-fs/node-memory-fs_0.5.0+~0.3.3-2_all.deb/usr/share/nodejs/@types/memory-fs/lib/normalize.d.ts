declare function normalize(path: string): string;

export = normalize;
