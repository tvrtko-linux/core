declare function join(path: string, request: string): string;

export = join;
