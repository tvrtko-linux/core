export declare const FormData: {
  new (): typeof FormData;
  prototype: typeof FormData;
};
export declare function formDataToBlob(formData: typeof FormData): Blob;
