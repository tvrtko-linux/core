"""Python client for Nvim.

This is a transition package. New projects should instead import pynvim package.
"""
import pynvim
from pynvim import *

__all__ = pynvim.__all__
