See http://pypi.python.org/pypi/rfc3987 or the docstrings in rfc3987.py.
