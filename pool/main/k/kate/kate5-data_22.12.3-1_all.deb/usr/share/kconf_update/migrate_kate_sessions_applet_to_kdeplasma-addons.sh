#!/bin/sh

# SPDX-FileCopyrightText: 2022 Alexander Lohnau <alexander.lohnau@gmx.de>
# SPDX-License-Identifier: MIT

sed -i 's/plugin=org\.kde\.plasma\.katesessions/plugin=org.kde.plasma.addons.katesessions/g' ~/.config/plasma-org.kde.plasma.desktop-appletsrc